
class TimeConst {
    /**一小时的秒数*/
    public static ONE_HOURS_SEC: number = 3600;
    /**一天的秒数*/
    public static ONE_DAY_SEC: number = 86400;
    /**一天的毫秒 */
    public static ONE_DAY_MILSEC: number = 86400000;
}