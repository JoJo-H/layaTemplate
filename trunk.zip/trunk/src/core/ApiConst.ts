
module core {

    export class ApiConst {
        
        static LoadingView : string = "LoadingView";
        static WaitView : string = "WaitView";
        static AlertView : string = "AlertView";
    }
}