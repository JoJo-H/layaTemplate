

module core {

    export interface IAlertView {
        dataSource:any;
        zOrder:number;
        btnNot:Laya.Button;
        btnYes:Laya.Button;
    }
}