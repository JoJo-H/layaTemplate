
class SkinUtil {
    //加载背景图
	static loadbg: string = "preload/loading2.jpg";
}