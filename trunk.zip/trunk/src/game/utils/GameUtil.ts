
module util {
    
    export class game {

        
    }
}