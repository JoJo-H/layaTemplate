
class RequestMsgHandler implements core.IMsgHandler{

    onHandler(msgid:number,msg?:string,data?:any):void{
        
    }
}