

module common {


    export class Player {

    }
}