
class UIConst {
    static hud_group: string = "hud";       // 一级界面
    /**二级界面group */
    static two_group: string = "two";
    static login_group: string = "login";
}